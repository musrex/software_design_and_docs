Software Design and Docs
Leandro Lopez - Week 5 Project

run - 'java com.merrimack.week5.App'
documentation in 'com/merrimack/week5'
